<?php
/**
 * RSVP Handler — Chenna Naik & Gayathri Bai Wedding
 * Saves RSVP responses to MySQL database
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

// ── Database Configuration ── 
// Update these credentials to match your MySQL setup
define('DB_HOST', 'localhost');
define('DB_USER', 'root');         // Your MySQL username
define('DB_PASS', '');             // Your MySQL password
define('DB_NAME', 'wedding_rsvp'); // Database name

/**
 * Create DB connection and table if not exists
 */
function getConnection(): ?mysqli {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        // Try creating the database first
        $conn2 = new mysqli(DB_HOST, DB_USER, DB_PASS);
        if ($conn2->connect_error) return null;

        $conn2->query("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $conn2->close();

        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) return null;
    }

    // Create table if not exists
    $sql = "CREATE TABLE IF NOT EXISTS rsvp_responses (
        id           INT AUTO_INCREMENT PRIMARY KEY,
        guest_name   VARCHAR(150)   NOT NULL,
        num_guests   TINYINT        NOT NULL DEFAULT 1,
        attending    ENUM('yes','no') NOT NULL,
        message      TEXT,
        submitted_at TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
        ip_address   VARCHAR(45)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $conn->query($sql);
    return $conn;
}

// ── Handle POST Request ──
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// ── Sanitize & Validate Input ──
$guestName = trim(strip_tags($_POST['guest_name'] ?? ''));
$numGuests = intval($_POST['num_guests'] ?? 1);
$attending  = trim($_POST['attending'] ?? '');
$message    = trim(strip_tags($_POST['message'] ?? ''));

$errors = [];

if (empty($guestName) || strlen($guestName) < 2) {
    $errors[] = 'Please enter a valid name.';
}
if ($numGuests < 1 || $numGuests > 20) {
    $errors[] = 'Number of guests must be between 1 and 20.';
}
if (!in_array($attending, ['yes', 'no'])) {
    $errors[] = 'Please select whether you are attending.';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// ── Save to Database ──
$conn = getConnection();

if (!$conn) {
    // If DB not available, log to file as fallback
    $logLine = date('Y-m-d H:i:s') . " | $guestName | $numGuests guests | Attending: $attending | $message\n";
    file_put_contents(__DIR__ . '/rsvp_log.txt', $logLine, FILE_APPEND | LOCK_EX);

    echo json_encode(['success' => true, 'message' => 'RSVP saved (file fallback)', 'fallback' => true]);
    exit;
}

$ip   = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
$stmt = $conn->prepare(
    "INSERT INTO rsvp_responses (guest_name, num_guests, attending, message, ip_address) VALUES (?, ?, ?, ?, ?)"
);

$stmt->bind_param('sisss', $guestName, $numGuests, $attending, $message, $ip);

if ($stmt->execute()) {
    $insertId = $conn->insert_id;
    $stmt->close();
    $conn->close();

    echo json_encode([
        'success'  => true,
        'message'  => 'RSVP submitted successfully!',
        'id'       => $insertId,
        'data'     => [
            'name'      => $guestName,
            'guests'    => $numGuests,
            'attending' => $attending
        ]
    ]);
} else {
    $error = $stmt->error;
    $stmt->close();
    $conn->close();

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $error]);
}
